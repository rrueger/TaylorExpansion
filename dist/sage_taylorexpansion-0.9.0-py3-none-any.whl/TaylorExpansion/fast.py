#!/usr/bin/env python3

from itertools import product
from sys import argv
from datetime import datetime
from multiprocessing import Manager, Pool, Lock
# from time import sleep
from random import choice as random_choice

# Sage modules
import sage.all
from sage.rings.integer_ring import ZZ
from sage.rings.rational_field import QQ
from sage.rings.finite_rings.integer_mod_ring import Zmod
from sage.rings.polynomial.polynomial_ring_constructor import PolynomialRing
from sage.rings.laurent_series_ring import LaurentSeriesRing
from sage.calculus.functional import derivative
from sage.sets.primes import Primes

# Silence warnings about slow implementations in the pre-processing step e.g.
#     verbose 0 (4176: multi_polynomial_ideal.py, groebner_basis)
#     Warning: falling back to very slow toy implementation.
try:
    from sage.misc.verbose import set_verbose
    set_verbose(-1)
except ImportError:
    try:
        from sage.misc.misc import set_verbose
        set_verbose(-1)
    except ImportError:
        pass


prec = 1000
pprec = 10
# Exclude 2 and 3 for now (2, 3 are the only factors of 12)
P = Primes().unrank_range(2, pprec)
(t, ) = PolynomialRing(ZZ, names=('t',))._first_ngens(1)
S = PolynomialRing(ZZ, names=('Q', 'R'))
(Q, R, ) = S._first_ngens(2)
rl = 2


def reduce(poly, n, lift=True):
    # Assumes poly is an element of PolynomialRing(ZZ, names=('t'))
    R = PolynomialRing(ZZ, names=('t'))
    T = R.change_ring(Zmod(n))
    # Don't need this based on assumption
    # (t, ) = T._first_ngens(1)
    S = T.quotient(t - t**n)
    if lift:
        return S(poly).lift()
    else:
        return S(poly)


def compute_weight(p):
    weights = [4*Q_power + 6*R_power for (Q_power, R_power) in p.exponents()]
    if all([weight == weights[0] for weight in weights]):
        return weights[0]
    print(f'{p} is not homogeneous!')
    exit(1)


def get_init_poly(p, order):
    (t, ) = PolynomialRing(ZZ, names=('t'))._first_ngens(1)

    if p == 0:
        return 0*t

    k = compute_weight(p)

    # # Sage implementation detail
    # # In theory, an approach like this would be ideal
    #
    # R1 = LaurentSeriesRing(QQ, names=('q')); (q, ) = R1._first_ngens(1)
    # R2 = LaurentSeriesRing(R1, names=('r')); (r, ) = R2._first_ngens(1)
    # R3 = PolynomialRing(R3, names=('w')); (w, ) = R3._first_ngens(1)
    #
    # if order == 3:
    #     S = R3.quotient(q**12 * r**(-8) - w)
    #     # ...
    # elif order == 2:
    #     S = R3.quotient(r**12 * q**(-18) - w)
    #     # ...
    #
    # # However, we have the following issue
    # print(S(q*r).lift())
    # q*r    # Here we want w!
    #
    # # So we are forced to use an approach like this (e.g. for order = 2)
    # R = LaurentSeriesRing(QQ, names=('q')); (q, ) = R._first_ngens(1)
    # RR = PolynomialRing(R, names=('r', 'w')); (r, w, ) = RR._first_ngens(2)
    # S = RR.quotient(q*r-w)
    # print(S(q*r).lift())
    # w

    if order == 3:
        # Point = \rho
        # R(\rho) != 0, so we can invert R:
        #     Q^a R^b = R^{k/6} (Q R^{-2/3})^a
        # Sage does not support fractional powers for LaurentSeriesRing
        # Think: r = R^{1/12}
        R = LaurentSeriesRing(QQ, names=('r'))
        (r, ) = R._first_ngens(1)
        # Think: q = Q^{1/12}
        # w is a helper variable used for the quotient
        RR = PolynomialRing(R, names=('q', 'w'))
        (q, w, ) = RR._first_ngens(2)
        # We want w = QR^{-2/3} = q^{12}r^{-8}
        S = RR.quotient(q**12 * r**(-8) - w)

        s = 0*q + 0*r
        for coef, (Q_power, R_power) in zip(p.coefficients(), p.exponents()):
            s += coef * q**(12*Q_power) * r**(12*R_power)
        s *= r**(-2*k)
        s = S(s).lift()

    elif order == 2:
        # Point = i
        # Q(i) != 0, so we can invert Q:
        #     Q^a R^b = Q^{k/4} (Q^{-3/2} R)^b
        # Sage does not support fractional powers for LaurentSeriesRing
        # Think: q = Q^{1/12}
        R = LaurentSeriesRing(QQ, names=('q'))
        (q, ) = R._first_ngens(1)
        # Think: r = R^{1/12}
        # w is a helper variable used for the quotient
        RR = PolynomialRing(R, names=('r', 'w'))
        (r, w, ) = RR._first_ngens(2)
        S = RR.quotient(r**12*q**(-18) - w)

        s = 0*q + 0*r
        for coef, (Q_power, R_power) in zip(p.coefficients(), p.exponents()):
            s += coef * q**(12*Q_power) * r**(12*R_power)
        s *= q**(-3*k)
        s = S(s).lift()

    p_init = 0*t
    # s is a polynomial in RR (it was sent to S and the lifted back to RR)
    # Therefore, although it is expressed only in the variable w, it is
    # formally in r and w (See the definition of RR)
    # So we throw away the first in every pair using (_, exp)
    for coef, (_, exp) in zip(s.coefficients(), s.exponents()):
        p_init += int(coef.subs(r=0, w=0, q=0))*t**exp

    return p_init


def detect_periodicity(it, verbose=True):
    for offset in range(len(it)):
        if verbose:
            print(f"\r  Finding periodicity. Trying offset: {offset}", end='', flush=True)
        for period in range(1, len(it) - 1 - offset):
            a = [it[offset+rep+period*k] == it[offset+rep] for (rep, k) in product(range(period), range(1, (len(it)-offset)//period))]
            # all([]) == True, so we first verify a is non-empty
            if a and all(a):
                return offset, period

    return 0, len(it)


def recursion(p0, p1, k, order, m=None):
    if m:
        p0 = reduce(p0, m)
        p1 = reduce(p1, m)
        def _reduce(poly): return reduce(poly, m)
    else:
        def _reduce(poly): return poly

    p = [p0, p1]

    if order == 2:
        # Recursion length. It is always 2 in our cases
        for n in range(2, prec):
            # This becomes p[n]
            p += [_reduce(6*(t**2-1)*derivative(p[-1]) - (k+2*n-2)*t*p[-1] - (n-1)*(n+k-2)*p[-2])]
    elif order == 3:
        # Recursion length. It is always 2 in our cases
        for n in range(2, prec):
            # This becomes p[n]
            p += [_reduce(4*(t**3-1)*derivative(p[-1]) - (k+2*n-2)*t**2*p[-1] - (n-1)*(n+k-2)*t*p[-2])]

    return p


def compute(f, order, verbose=True):

    def log(*args, **kwargs):
        if verbose:
            print(*args, **kwargs)

    log("#" * 80)
    if order == 2:
        log(f"f = {f}, Expansion around i (point of order 2)")
    elif order == 3:
        log(f"f = {f}, Expansion around \\rho (point of order 3)")
    log("#" * 80)

    k = compute_weight(f)
    log(k, f, order)

    p0 = get_init_poly(f, order)
    p0_theta = -(4*R*derivative(f, Q) + 6*Q**2*derivative(f, R))
    p1 = get_init_poly(p0_theta, order)

    log("Initial polynomials are")
    log()
    if order == 2:
        p0_str = f"Q^{{-{k}/4}} * ({f})"
        p0_theta_str = f"Q^{{-{k}/4}} * ({p0_theta})"
        p1_str = f"Q^{{-{k+2}/4}} \\theta({f})"

    elif order == 3:
        p0_str = f"R^{{-{k}/6}}*({f})"
        p0_theta_str = f"R^{{-{k+2}/6}} * ({p0_theta})"
        p1_str = f"R^{{-{k+2}/6}} \\theta({f})"

    max_length_0 = max([len(str(p0)), len(str(p1))])
    max_length_1 = max([len(p0_str), len(p1_str)])

    log(f"  p0 = {str(p0).ljust(max_length_0)} = {p0_str.ljust(max_length_1)}")
    log(f"  p1 = {str(p1).ljust(max_length_0)} = {p1_str.ljust(max_length_1)} = {p0_theta_str}")
    log()

    log(f"Finding prime candidates amongst the first {prec} primes (up to {P[-1]})")
    log()

    success = 0
    for d in [5, 7]:
    # while True:
        # d = random_choice(P)
        # print(d)
        log(f"  Computing polynomials modulo {d}...", end=' ', flush=True)
        start = datetime.now()
        p = recursion(p0, p1, k, order, m=d)
        # for i in p:
        #     print(i)
        # Not sure about malloc implications of this
        # I hope python implements this as a generator
        diff = datetime.now() - start
        log(f'Done (took {round((diff.seconds*10**6+diff.microseconds)/10**6,3)}s).')

        # Use generator expression instead of a list comprehension for lazy
        # eval
        # https://stackoverflow.com/a/64090763
        start = datetime.now()
        if any(all([poly.subs(t=0) != 0 for n, poly in enumerate(p[::order][offset:])]) for offset in range(prec-rl*4)):
            diff = datetime.now() - start
            # This candidate bodes well
            log(f"  Eventually all p_{{{order}*n}}(0) non-zero (mod {d}) (took {round((diff.seconds*10**6+diff.microseconds)/10**6,3)}s).")
            start = datetime.now()
            offset, period = detect_periodicity(p, verbose=verbose)
            diff = datetime.now() - start
            log(f" (took {round((diff.seconds*10**6+diff.microseconds)/10**6,3)}s).")
            if period < len(p):
                # success += 1
                log(f"  p_n(t) (mod {d}) is eventually periodic")
                log(f"    offset = {offset}")
                log(f"    period = {period}")
                print(f"weight = {k}, order = {order}, fn = {f}, prime = {d}, offset = {offset}, period = {period}")
                break
                # if success > 4:
                #     break


                # Comment to see other candidates and their periods
                # if period == 2*order*d:
                #     log(f"    weight = {k}, fn = {f}, prime = {d}, offset = {offset}, period = {period}")
                #     log("    This satisfies the conjecture!")
                #     log()
                #     log()
                #     break
                # else:
                #     log("  Does not satisfy the conjecture. Continuing search.")
                #     break
            else:
                log("  Could not find a period.")
        else:
            log(f"{d} is not a good candidate. There are zero-coefficients.")

        log()

    # log()

    # if not success:
    #     log("No good (enough) candidates found.")
    #     exit(1)

    # poly_str = [f"p_{n}(t) = {reduce(poly, d)}" for n, poly in enumerate(p[:offset+period+rl*2])]
    # max_len = max([len(poly) for poly in poly_str])

    # if offset:
    #     log()
    #     log(f"The first {offset} non-periodic polynomials")
    #     log()
    #     for poly in poly_str[:offset]:
    #         log(f"  {poly.ljust(max_len)} (mod {d})")

    # log()
    # log(f"Here is a repeating period of {period} polynomials")
    # log("This sequence repeats forever")
    # log()
    # for poly in poly_str[offset:offset+period]:
    #     log(f"  {poly.ljust(max_len)} (mod {d})")
    # for n, poly in enumerate(poly_str[offset+period:offset+period+rl*2]):
    #     log(f"  {poly.ljust(max_len)} (mod {d}) = p_{n+offset}(t)")
    # log("  ...")

    # values = [int(poly.subs(t=0)) for poly in p[::order]]
    # offset, period = detect_periodicity(values, d)

    # log()
    # log(f"Moreover, we have the following repeating sequence modulo {d}")
    # log()
    # for i in range(period):
    #     log(f"  p_{{{order}n}}(0) = {reduce(values[offset+i], d)} (mod {d}) for n > {offset*order} and n = {(offset + i) % period} (mod {period})")
    # log()


def M(k):
    if k % 2:
        return []
    r = []
    for n in range(k):
        b1 = -k//2 + 3*n
        b2 = k//2 - 2*n
        if b1 >= 0 and b2 >= 0:
            r += [[b1, b2]]
    return r


forms = []
for weight in range(0, 30, 2):
    for q, r in M(weight):
        forms += [Q**q * R**r]


# def compute2(f): compute(f, 2, verbose=False)
# def compute3(f): compute(f, 3, verbose=False)
def compute6(f): compute(f, 2, verbose=False); compute(f, 3, verbose=False)


# for form in forms:
#     compute2(form)
#     compute3(form)

with Pool(processes=17) as pool:
    pool.map(compute6, forms)

# # Or call within script
# # k = 12. Dim M_k = 2
# compute(Q**3 - R**2, 2)
# compute(Q**3 + R**2, 2)
# compute(Q**3, 3)
# f = Q**3
# k = 12
# order = 2
# p0 = get_init_poly(f, order)
# p0_theta = -(4*R*derivative(f, Q) + 6*Q**2*derivative(f, R))
# p1 = get_init_poly(p0_theta, order)
# p = recursion(p0, p1, k, order, m=None)
# for n, i in enumerate(p):
#     print(n, i)
#     print()
# compute(Q**3, 2)
# # k = 14
# compute(Q**2*R, 2)
# compute(Q**2*R, 3)
# # k = 24
# compute(Q**6 - R**4, 2)

# if __name__ == "__main__":
#     with Pool(processes=17) as pool:
#         pool.imap_unordered(compute6, forms)
#         pool.close()
#         pool.join()

#     if len(argv) > 2:
#         compute(S(argv[1]), int(argv[2]))
#     else:
#         print("Call with function (e.g. 'Q^3 - R^2') and order (2 or 3)")
#         print("Full example: python3 script.py 'Q^3 - R^2' 2")
#         exit(1)
