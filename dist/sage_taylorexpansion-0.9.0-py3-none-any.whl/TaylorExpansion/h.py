#!/usr/bin/python3

from time import sleep
from multiprocessing import Pool

class op_pairs_p_first:
    def __init__(self, it):
        self.len = len(it)

    def __iter__(self):
        self.offset = 0
        self.period = 1
        self.len = self.len
        return self

    def __next__(self):
        offset = self.offset
        period = self.period
        if period + offset < self.len:
            self.period += 1
            return (offset, period)
        elif offset > self.len - 1:
            raise StopIteration
        else:
            self.period = 1
            self.offset += 1
            return (offset, period)


def f(op_pair):
    print(f"started with {op_pair}")
    offset = op_pair[0]
    period = op_pair[1]
    sleep(1)
    return offset, period


i = iter(op_pairs_p_first(list(range(10))))

with Pool(processes=4) as pool:
    for offset, period in pool.map(f, i):
        print(offset, period)
        break
