#!/use/bin/env python3

from itertools import product
from sys import argv
from datetime import datetime

# Sage modules
import sage.all
from sage.rings.integer_ring import ZZ
from sage.rings.rational_field import QQ
from sage.rings.finite_rings.integer_mod_ring import Zmod
from sage.rings.polynomial.polynomial_ring_constructor import PolynomialRing
from sage.rings.laurent_series_ring import LaurentSeriesRing
from sage.calculus.functional import derivative
from sage.sets.primes import Primes

# Silence warnings about slow implementations in the pre-processing step e.g.
#     verbose 0 (4176: multi_polynomial_ideal.py, groebner_basis)
#     Warning: falling back to very slow toy implementation.
try:
    from sage.misc.verbose import set_verbose
    set_verbose(-1)
except ImportError:
    try:
        from sage.misc.misc import set_verbose
        set_verbose(-1)
    except ImportError:
        pass


prec = 1000
pprec = 100
# Exclude 2 and 3 for now (2, 3 are the only factors of 12)
P = Primes().unrank_range(2, pprec)
(t, ) = PolynomialRing(ZZ, names=('t',))._first_ngens(1)
S = PolynomialRing(ZZ, names=('Q', 'R'))
(Q, R, ) = S._first_ngens(2)
rl = 2


def reduce(poly, n, lift=True):
    # Assumes poly is an element of PolynomialRing(ZZ, names=('t'))
    R = PolynomialRing(ZZ, names=('t'))
    T = R.change_ring(Zmod(n))
    # Don't need this based on assumption
    # (t, ) = T._first_ngens(1)
    S = T.quotient(t - t**n)
    if lift:
        return S(poly).lift()
    else:
        return S(poly)


def compute_weight(p, check=True):
    if check:
        weights = [4*Q_power + 6*R_power for (Q_power, R_power) in p.exponents()]
        if all([weight == weights[0] for weight in weights]):
            return weights[0]
        print(f'{p} is not homogeneous!')
        exit(1)
    else:
        Q_power, R_power = p.exponents()[0]
        return 4*Q_power + 6*R_power


def init_poly(p, order):
    (t, ) = PolynomialRing(ZZ, names=('t'))._first_ngens(1)

    if p == 0:
        return 0*t

    k = compute_weight(p)

    if order == 3:
        R = LaurentSeriesRing(QQ, names=('r'))
        (r, ) = R._first_ngens(1)
        RR = PolynomialRing(R, names=('q', 'w'))
        (q, w, ) = RR._first_ngens(2)
        S = RR.quotient(q**12 * r**(-8) - w)

        s = 0*q + 0*r
        for coef, (Q_power, R_power) in zip(p.coefficients(), p.exponents()):
            s += coef * q**(12*Q_power) * r**(12*R_power)
        s *= r**(-2*k)
        s = S(s).lift()

    elif order == 2:
        R = LaurentSeriesRing(QQ, names=('q'))
        (q, ) = R._first_ngens(1)
        RR = PolynomialRing(R, names=('r', 'w'))
        (r, w, ) = RR._first_ngens(2)
        S = RR.quotient(r**12*q**(-18) - w)

        s = 0*q + 0*r
        for coef, (Q_power, R_power) in zip(p.coefficients(), p.exponents()):
            s += coef * q**(12*Q_power) * r**(12*R_power)
        s *= q**(-3*k)
        s = S(s).lift()

    p_init = 0*t
    for coef, (_, exp) in zip(s.coefficients(), s.exponents()):
        p_init += int(coef.subs(r=0, w=0, q=0))*t**exp

    return p_init


def recursion(p0, p1, order):
    p = [p0, p1]
    if order == 2:
        for n in range(2, prec):
            if n == 8:
                print(6*t**2-1*derivative(p[-1]) - (k+2*n-2)*t*p[-1] - (n-1)*(n+10)*p[-2])
            p += [_reduce(6*t**2-1*derivative(p[-1]) - (k+2*n-2)*t*p[-1] - (n-1)*(n+10)*p[-2])]
    elif order == 3:
        for n in range(2, prec):
            p += [_reduce(4*(t**3-1)*derivative(p[-1]) - (k+2*n-2)*t**2*p[-1] - (n-1)*(n+k-2)*t*p[-2])]
    return p


if len(argv) > 2:
    f = S(argv[1])
    order = int(argv[2])
    d = int(argv[3])
else:
    f = Q**3 - R**2
    order = 2
    d = 5

print("#" * 80)
if order == 2:
    print(f"f = {f}, Expansion around i (point of order 2)")
elif order == 3:
    print(f"f = {f}, Expansion around \\rho (point of order 3)")
print("#" * 80)

k = compute_weight(f)
print(k, f, order)

p0 = init_poly(f, order)
theta_p0 = -(4*R*derivative(f, Q) + 6*Q**2*derivative(f, R))
p1 = init_poly(theta_p0, order)

print("Initial polynomials are")
print()
if order == 2:
    p0_str = f"Q^{{-{k}/4}} * ({f})"
    theta_p0_str = f"Q^{{-{k}/4}} * ({theta_p0})"
    p1_str = f"Q^{{-{k+2}/4}} \\theta({f})"

elif order == 3:
    p0_str = f"R^{{-{k}/6}}*({f})"
    theta_p0_str = f"R^{{-{k+2}/6}} * ({theta_p0})"
    p1_str = f"R^{{-{k+2}/6}} \\theta({f})"

max_length_0 = max([len(str(p0)), len(str(p1))])
max_length_1 = max([len(p0_str), len(p1_str)])

print(f"  p0 = {str(p0).ljust(max_length_0)} = {p0_str.ljust(max_length_1)}")
print(f"  p1 = {str(p1).ljust(max_length_0)} = {p1_str.ljust(max_length_1)} = {theta_p0_str}")
print()

start = datetime.now()
for i in range(1):
    def _reduce(poly): return poly
    p_bn = recursion(p0, p1, order)
    def _reduce(poly): return reduce(poly, d)
    p_bn = [_reduce(poly) for poly in p_bn]
diff = datetime.now() - start
print(f'Reducing at end: 10 runs took {round((diff.seconds*10**6+diff.microseconds)/10**6,3)}s.')

start = datetime.now()
for i in range(1):
    def _reduce(poly): return poly % d
    p_bc = recursion(p0, p1, order)
    def _reduce(poly): return reduce(poly, d)
    p_bc = [_reduce(poly) for poly in p_bc]
diff = datetime.now() - start
print(f'Reducing polys at end, reducing coefficients during recursion: 10 runs took {round((diff.seconds*10**6+diff.microseconds)/10**6,3)}s.')
print(p_bc == p_bn)

start = datetime.now()
for i in range(1):
    def _reduce(poly): return reduce(poly, d)
    p_a = recursion(reduce(p0, d), reduce(p1, d), order)
diff = datetime.now() - start
print(f'Reducing in each step: 10 runs took {round((diff.seconds*10**6+diff.microseconds)/10**6,3)}s.')

n = 5
# Assumes poly is an element of PolynomialRing(ZZ, names=('t'))
R = PolynomialRing(ZZ, names=('t'))
T = R.change_ring(Zmod(n))
# Don't need this based on assumption
# (t, ) = T._first_ngens(1)
S = T.quotient(t - t**n)

for n, (i, j) in enumerate(zip(p_a[:20], p_bn[:20])):
    print(f"{n} after  {i}")
    print(f"{n} before {j}")
    print(f"{n} {S(i-j).lift()}, is zero {S(i-j).lift() == 0}")
    if str(i) != str(j):
        print(f"^^^NOT THE SAME: diff {S(i-j)}")
        print()
        exit(1)
