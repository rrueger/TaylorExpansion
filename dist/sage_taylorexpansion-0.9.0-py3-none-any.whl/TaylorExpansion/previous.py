#!/use/bin/env python3

from itertools import product
from sys import argv
from datetime import datetime
from multiprocessing import Pool
from os import sched_getaffinity

# Sage modules
import sage.all
from sage.rings.integer_ring import ZZ
from sage.rings.rational_field import QQ
from sage.rings.finite_rings.integer_mod_ring import Zmod
from sage.rings.polynomial.polynomial_ring_constructor import PolynomialRing
from sage.rings.laurent_series_ring import LaurentSeriesRing
from sage.calculus.functional import derivative
from sage.sets.primes import Primes
from sage.arith.misc import divisors

# Silence warnings about slow implementations in the pre-processing step e.g.
#     verbose 0 (4176: multi_polynomial_ideal.py, groebner_basis)
#     Warning: falling back to very slow toy implementation.
try:
    from sage.misc.verbose import set_verbose
    set_verbose(-1)
except ImportError:
    try:
        from sage.misc.misc import set_verbose
        set_verbose(-1)
    except ImportError:
        pass


def reduce(poly, n, lift=True):
    # Assumes poly is an element of PolynomialRing(ZZ, names=('t'))
    R = PolynomialRing(ZZ, names=('t'))
    T = R.change_ring(Zmod(n))
    # Don't need this based on assumption
    # (t, ) = T._first_ngens(1)
    S = T.quotient(t - t**n)
    if lift:
        return S(poly).lift()
    else:
        return S(poly)

    return poly % n

def Mk_basis(k):
    if k % 2:
        return []
    elif k == 0:
        return [R**0*Q**0]
    basis = []
    for n in range(k):
        b1 = -k//2 + 3*n
        b2 = k//2 - 2*n
        if b1 >= 0 and b2 >= 0:
            basis += [Q**b1*R**b2]
    return basis


def Mk_mod_n(k, n):
    basis = Mk_basis(k)
    elts = []
    for coefs in product(range(n), repeat=len(basis)):
        elts += [sum([basis[i]*coefs[i] for i, _ in enumerate(basis)])]
    # Do not return 0 (the first element)
    return elts[1:]


def dim(k):
    return k//12 if k % 12 == 2 else k//12 + 1


def compute_weight(p, check=True):
    if p == 0:
        return 0

    if check:
        weights = [4*Q_power + 6*R_power for (Q_power, R_power) in p.exponents()]
        if all([weight == weights[0] for weight in weights]):
            return weights[0]
        print(f'{p} is not homogeneous!')
        exit(1)
    else:
        Q_power, R_power = p.exponents()[0]
        return 4*Q_power + 6*R_power


def init_poly(p, order, OS=False):
    (t, ) = PolynomialRing(ZZ, names=('t'))._first_ngens(1)

    k = compute_weight(p)

    if OS:
        if k != 12:
            print("Error. O'Sullivan-Risager variant only for forms of weight 12")
            print(f"{f} is of weight {k}")
            exit(1)
        return 1

    if p == 0:
        return 0*t

    # # Sage implementation detail
    # # In theory, an approach like this would be ideal
    #
    # R1 = LaurentSeriesRing(QQ, names=('q')); (q, ) = R1._first_ngens(1)
    # R2 = LaurentSeriesRing(R1, names=('r')); (r, ) = R2._first_ngens(1)
    # R3 = PolynomialRing(R3, names=('w')); (w, ) = R3._first_ngens(1)
    #
    # if order == 3:
    #     S = R3.quotient(q**12 * r**(-8) - w)
    #     # ...
    # elif order == 2:
    #     S = R3.quotient(r**12 * q**(-18) - w)
    #     # ...
    #
    # # However, we have the following issue
    # print(S(q*r).lift())
    # q*r    # Here we want w!
    #
    # # So we are forced to use an approach like this (e.g. for order = 2)
    # R = LaurentSeriesRing(QQ, names=('q')); (q, ) = R._first_ngens(1)
    # RR = PolynomialRing(R, names=('r', 'w')); (r, w, ) = RR._first_ngens(2)
    # S = RR.quotient(q*r-w)
    # print(S(q*r).lift())
    # w

    if order == 3:
        # Point = \rho
        # R(\rho) != 0, so we can invert R:
        #     Q^a R^b = R^{k/6} (Q R^{-2/3})^a
        # Sage does not support fractional powers for LaurentSeriesRing
        # Think: r = R^{1/12}
        R = LaurentSeriesRing(QQ, names=('r'))
        (r, ) = R._first_ngens(1)
        # Think: q = Q^{1/12}
        # w is a helper ariable used for the quotient
        RR = PolynomialRing(R, names=('q', 'w'))
        (q, w, ) = RR._first_ngens(2)
        # We want w = QR^{-2/3} = q^{12}r^{-8}
        S = RR.quotient(q**12 * r**(-8) - w)

        s = 0*q + 0*r
        for coef, (Q_power, R_power) in zip(p.coefficients(), p.exponents()):
            s += coef * q**(12*Q_power) * r**(12*R_power)
        s *= r**(-2*k)
        s = S(s).lift()

    elif order == 2:
        # Point = i
        # Q(i) != 0, so we can invert Q:
        #     Q^a R^b = Q^{k/4} (Q^{-3/2} R)^b
        # Sage does not support fractional powers for LaurentSeriesRing
        # Think: q = Q^{1/12}
        R = LaurentSeriesRing(QQ, names=('q'))
        (q, ) = R._first_ngens(1)
        # Think: r = R^{1/12}
        # w is a helper variable used for the quotient
        RR = PolynomialRing(R, names=('r', 'w'))
        (r, w, ) = RR._first_ngens(2)
        S = RR.quotient(r**12*q**(-18) - w)

        s = 0*q + 0*r
        for coef, (Q_power, R_power) in zip(p.coefficients(), p.exponents()):
            s += coef * q**(12*Q_power) * r**(12*R_power)
        s *= q**(-3*k)
        s = S(s).lift()

    p_init = 0*t
    # s is a polynomial in RR (it was sent to S and the lifted back to RR)
    # Therefore, although it is expressed only in the variable w, it is
    # formally in r and w (See the definition of RR)
    # So we throw away the first in every pair using (_, exp)
    for coef, (_, exp) in zip(s.coefficients(), s.exponents()):
        p_init += int(coef.subs(r=0, w=0, q=0))*t**exp

    return p_init


def detect_periodicity(it, rd=2, verbose=True, period_first=False):
    # This works for sequences generated by a recursion whose depth is rd
    def vprint(*args, **kwargs):
        if verbose: print(*args, **kwargs)
    vprint("Finding periodicity.")
    if period_first:
        for period, _ in enumerate(it):
            vprint(f"\rTrying period: {period} ", end='', flush=True)
            for offset in range(0, len(it) - 1 - period):
                if it[offset:offset+rd] == it[offset+period:offset+period+rd]:
                    return offset, period
    else:
        for offset, _ in enumerate(it):
            vprint(f"\rTrying offset: {offset} ", end='', flush=True)
            for period in range(1, len(it) - 1 - offset):
                if it[offset:offset+rd] == it[offset+period:offset+period+rd]:
                    return offset, period

    return 0, None


def recursion(f, order, d=None, verbose=True, OS=False):
    def vprint(*args, **kwargs):
        if verbose: print(*args, **kwargs)

    k = compute_weight(f)

    if OS and k != 12:
        print("Error. O'Sullivan-Risager variant only for forms of weight 12")
        print(f"{f} is of weight {k}")
        exit(1)

    vprint("#" * 80)
    if order == 2:
        vprint(f"f = {f} (weight {k}), Expansion around i (point of order 2)")
    elif order == 3:
        vprint(f"f = {f} (weight {k}), Expansion around \\rho (point of order 3)")
    vprint("#" * 80)
    vprint(f"Computing polynomials modulo {d}... ", end='', flush=True)

    if OS:
        f = S(f/(Q**3))
    p0 = init_poly(f, order)
    theta_p0 = -(4*R*derivative(f, Q) + 6*Q**2*derivative(f, R))
    p1 = init_poly(theta_p0, order)

    start = datetime.now()

    if order == 2:
        p0_str = f"Q^{{-{k}/4}} * ({f})"
        theta_p0_str = f"Q^{{-{k}/4}} * ({theta_p0})"
        p1_str = f"Q^{{-{k+2}/4}} \\theta({f})"

    elif order == 3:
        p0_str = f"R^{{-{k}/6}}*({f})"
        theta_p0_str = f"R^{{-{k+2}/6}} * ({theta_p0})"
        p1_str = f"R^{{-{k+2}/6}} \\theta({f})"

    # Reduce the coefficients to make the computations faster (the coefficients
    # grow exponentially, in part because we are multiplying by 12**n every
    # iteration)
    def _reduce(poly): return poly % d if d else poly

    p = [_reduce(p0), _reduce(p1)]

    # Put loop inside condition to prevent unecessary condition checks
    if order == 2 and OS:
        for n in range(2, prec):
            # This becomes p[n]
            # O'Sullivan-Risager variant, valid only for k = 12
            p += [_reduce(
                    6*(t**2-1)*derivative(p[-1])
                    - 2*(n-1)*t*p[-1]
                    - (n-1)*(n+10)*p[-2]
                 )]
    elif order == 2 and not OS:
        # This becomes p[n]
        for n in range(2, prec):
            p += [_reduce(
                    6*(t**2-1)*derivative(p[-1])
                    - (k+2*n-2)*t*p[-1]
                    - (n-1)*(n+10)*p[-2]
                 )]
    elif order == 3 and OS:
        for n in range(2, prec):
            # This becomes p[n]
            # O'Sullivan-Risager variant, valid only for k = 12
            p += [_reduce(
                    4*(t**3-1)*derivative(p[-1])
                    - 2*(n-1)*t**2*p[n-1]
                    - (n-1)*(n+10)*t*p[n-2]
                 )]
    elif order == 3 and not OS:
        for n in range(2, prec):
            # This becomes p[n]
            p += [_reduce(
                    4*(t**3-1)*derivative(p[-1])
                    - (k+2*n-2)*t**2*p[-1]
                    - (n-1)*(n+k-2)*t*p[-2]
                 )]

    # Now perform full reduction
    def _reduce(poly): return reduce(poly, d) if d else poly

    p = [_reduce(poly) for poly in p]

    diff = datetime.now() - start
    vprint(f'Done (took {(diff.seconds*10**6+diff.microseconds)/10**6:.3f})s).')

    vprint("Initial polynomials are")
    vprint()
    max_length_0 = max([len(str(p0)), len(str(p1))])
    max_length_1 = max([len(p0_str), len(p1_str)])

    vprint(f"  p0 = {str(p0):<{max_length_0}} = {p0_str:<{max_length_1}}")
    vprint(f"  p1 = {str(p1):<{max_length_0}} = {p1_str:<{max_length_1}}"
           f" = {theta_p0_str}"
          )
    vprint()

    return p


class Recursion:
    def vprint(self, *args, **kwargs):
        if self.verbose:
            print(*args, **kwargs)

    def _reducemod(self, poly): return poly % self.d if self.d else poly

    def _reduce(self, poly): return reduce(poly, self.d) if self.d else poly

    def __init__(self, f, order, d=None, verbose=True, OS=False):
        self.n = 0
        self.order = order
        self.d = d
        self.verbose = verbose
        self.OS = OS
        self.k = compute_weight(f)

        if self.OS:
            self.f = S(f/(Q**3))
        else:
            self.f = f

        if OS and self.k != 12:
            print("Error. O'Sullivan-Risager variant only for forms of weight 12")
            print(f"{f} is of weight {self.k}")
            exit(1)

        self.vprint("#" * 80)
        if order == 2:
            self.vprint(f"f = {self.f} (weight {self.k}), Expansion around i (point of order 2)")
        elif order == 3:
            self.vprint(f"f = {self.f} (weight {self.k}), Expansion around \\rho (point of order 3)")
        self.vprint("#" * 80)

        self.p0 = init_poly(self.f, order)
        theta_p0 = -(4*R*derivative(self.f, Q) + 6*Q**2*derivative(self.f, R))
        self.p1 = init_poly(theta_p0, order)

        if order == 2:
            p0_str = f"Q^{{-{self.k}/4}} * ({self.f})"
            theta_p0_str = f"Q^{{-{self.k}/4}} * ({theta_p0})"
            p1_str = f"Q^{{-{self.k+2}/4}} \\theta({self.f})"

        elif order == 3:
            p0_str = f"R^{{-{self.k}/6}}*({self.f})"
            theta_p0_str = f"R^{{-{self.k+2}/6}} * ({theta_p0})"
            p1_str = f"R^{{-{self.k+2}/6}} \\theta({self.f})"

        self.vprint("Initial polynomials are")
        self.vprint()
        max_length_0 = max([len(str(self.p0)), len(str(self.p1))])
        max_length_1 = max([len(p0_str), len(p1_str)])

        self.vprint(f"  p0 = {str(self.p0):<{max_length_0}} = {p0_str:<{max_length_1}}")
        self.vprint(f"  p1 = {str(self.p1):<{max_length_0}} = {p1_str:<{max_length_1}}"
               f" = {theta_p0_str}"
              )
        self.vprint()

    def __iter__(self): return self

    def __next__(self):
        if self.n == 0:
            self.n += 1
            return self.p0
        elif self.n == 1:
            self.n += 1
            return self.p1

        if self.order == 2 and self.OS:
            p2 = self._reducemod(6*(t**2-1)*derivative(self.p1)
                                 - 2*(self.n-1)*t*self.p1
                                 - (self.n-1)*(self.n+10)*self.p0)
        elif self.order == 2 and not self.OS:
            p2 = self._reducemod(6*(t**2-1)*derivative(self.p1)
                                 - (self.k+2*self.n-2)*t*self.p1
                                 - (self.n-1)*(self.n+10)*self.p0)
        elif self.order == 3 and self.OS:
            p2 = self._reducemod(4*(t**3-1)*derivative(self.p1)
                                 - 2*(self.n-1)*t**2*self.p1
                                 - (self.n-1)*(self.n+10)*t*self.p0)
        elif self.order == 3 and not self.OS:
            p2 = self._reducemod(4*(t**3-1)*derivative(self.p1)
                                 - (self.k+2*self.n-2)*t**2*self.p1
                                 - (self.n-1)*(self.n+self.k-2)*t*self.p0)

        self.n += 1
        self.p0, self.p1 = self.p1, p2
        return self._reduce(self.p1)


def offset_mod_d(p, order):
    # Use generator expression instead of a list comprehension for lazy eval
    # https://stackoverflow.com/a/64090763
    for offset, _ in enumerate(p):
        if all((poly.subs(t=0) != 0 for poly in p[::order][offset:])):
            return offset
    return None


def pprint(p, d, period, offset, order, rd=2, verbose=True):
    def vprint(*args, **kwargs):
        if verbose:
            print(*args, **kwargs)

    poly_str = [f"p_{n}(t) = {reduce(poly, d)}"
                for n, poly in enumerate(p[:offset+period+rd*2])]
    max_len = max([len(poly) for poly in poly_str])

    if offset:
        vprint()
        vprint(f"The first {offset} non-periodic polynomials")
        vprint()
        for poly in poly_str[:offset]:
            vprint(f"  {poly.ljust(max_len)} (mod {d})")

    vprint()
    vprint(f"Here is a repeating period of {period} polynomials")
    vprint("This sequence repeats forever")
    vprint()
    for poly in poly_str[offset:offset+period]:
        vprint(f"  {poly.ljust(max_len)} (mod {d})")
    for n, poly in enumerate(poly_str[offset+period:offset+period+rd*2]):
        vprint(f"  {poly.ljust(max_len)} (mod {d}) = p_{n+offset}(t)")
    vprint("  ...")

    vprint()
    vprint("Now finding periodic behaviour of p_n(t=0)")
    values = [int(poly.subs(t=0)) for poly in p[::order]]
    offset, period = detect_periodicity(values, d, verbose=verbose)

    vprint()
    vprint(f"Moreover, we have the following repeating sequence modulo {d}")
    vprint()
    for i in range(period):
        vprint(f"  p_{{{order}n}}(0) = {reduce(values[offset+i], d)} (mod {d})"
               f" for n > {offset*order}"
               f" and n = {(offset + i) % period} (mod {period})"
               )
    vprint()


def compute(f, order, candidate=None, max_candidates=1, verbose=True, OS=False):
    def vprint(*args, **kwargs):
        if verbose:
            print(*args, **kwargs)

    return_str = []

    k = compute_weight(f)

    candidates = [candidate] if candidate else P
    successful_candidates = 0

    for d in candidates:
        p = recursion(f, order, d=d, verbose=verbose, OS=OS)

        start = datetime.now()
        offset = offset_mod_d(p, order)
        if offset is not None:
            diff = datetime.now() - start
            # This candidate bodes well
            vprint(f"Eventually all p_{{{order}*n}}(0) non-zero (mod {d})"
                    f" (took {(diff.seconds*10**6+diff.microseconds)/10**6:.3f}s)."
                    )
            start = datetime.now()
            offset, period = detect_periodicity(p, verbose=verbose)
            diff = datetime.now() - start
            vprint(f"(took {(diff.seconds*10**6+diff.microseconds)/10**6:.3f}s).")
            if period is not None:
                vprint()
                vprint(f"p_n(t) (mod {d}) is eventually periodic with"
                       f" period = {period} and offset = {offset}"
                       )
                if verbose:
                    pprint(p, d, period, offset, order, verbose=verbose)

                successful_candidates += 1
                return_str += [f"weight = {k:>3}, order = {order:>3},"
                                f" fn = {str(f):<20}, prime = {d:>3},"
                                f" offset = {offset:>3}, period = {period:>4}"
                                ]
            else:
                return_str += [f"weight = {k:>3}, order = {order:>3},"
                                f" fn = {str(f):<20}, prime = {d:>3},"
                                f" Could not find period/offset"
                                ]
        else:
            return_str += [f"weight = {k:>3}, order = {order:>3},"
                            f" fn = {str(f):<20}, prime = {d:>3},"
                            " Not a good candidate. There are zero-coefficients."
                            ]

        if successful_candidates == max_candidates:
            return return_str


def compute2(f, order, candidate=None, max_candidates=1, verbose=True, OS=False):
    def vprint(*args, **kwargs):
        if verbose:
            print(*args, **kwargs)


    k = compute_weight(f)

    candidates = [candidate] if candidate else P

    for d in candidates:
        R = Recursion(f, order, d=d, verbose=verbose, OS=OS)
        n = 0
        rd = 2*d
        seen = [next(R) for _ in range(rd)]
        N = 0
        while not N:
            seen += [next(R)]
            for slide in range(1, len(seen)-rd):
                if seen[-rd:] == seen[-rd-slide:-slide]:
                    # Sequence is N periodic
                    N = slide
                    break
        # We know that len(seen) > offset + period
        seen += [next(R) for _ in range(len(seen))]
        # Now seen has at least two periods
        # Now we find the offset
        for offset in range(len(seen)//2):
            if seen[offset:offset+N] == seen[offset+N:offset+2*N]:
                break
        # Now we have the offset, and a multiple of the period
        for div in divisors(N):
            if all([seen[offset:offset+div] == seen[offset+div*k:offset+div*(k+1)] for k in range(1, N//d)]):
                break

        period = div
        print(len(seen))
        if verbose:
            pprint(seen, d, period, offset, order, verbose=verbose)
        return [f"weight = {k:>3}, order = {order:>3}, fn = {str(f):<20}, prime = {d:>3}, offset = {offset:>3}, period = {period:>4}"]

if __name__ == "__main__":
    # Exclude 2 and 3 for now (2, 3 are the only factors of 12)
    prec = 10000
    pprec = 1000
    P = Primes().unrank_range(2, 1000)
    (t, ) = PolynomialRing(ZZ, names=('t',))._first_ngens(1)
    S = PolynomialRing(ZZ, names=('Q', 'R'))
    (Q, R, ) = S._first_ngens(2)

    # Protect entrypoint for multiprocessing for platforms using spawn
    # def multi_compute(f): return compute(f, 2, candidate=5, verbose=False)
    # candidate = 5
    # for weight in range(2, 20, 2):
    #     forms = Mk_mod_n(weight, candidate)
    #     print(f"Got {len(forms)} weight {weight} forms")

    #     with Pool(processes=len(sched_getaffinity(0))+1) as pool:
    #         for n, response in enumerate(pool.imap_unordered(multi_compute, forms)):
    #             for line in response:
    #                 print(f"{n+1:>4}/{len(forms)} = {(n+1)/len(forms)*100:z5.1f}%, ", line)

    # # Protect entrypoint for multiprocessing for platforms using spawn
    # def multi_compute(f): return compute2(f, 2, candidate=5, verbose=False)
    # candidate = 5
    # for weight in range(2, 20, 2):
    #     forms = Mk_mod_n(weight, candidate)
    #     print(f"Got {len(forms)} weight {weight} forms")

    #     with Pool(processes=len(sched_getaffinity(0))+1) as pool:
    #         for n, response in enumerate(pool.imap_unordered(multi_compute, forms)):
    #             for line in response:
    #                 print(f"{n+1:>4}/{len(forms)} = {(n+1)/len(forms)*100:z5.1f}%, ", line)

    # Protect entrypoint for multiprocessing for platforms using spawn
    # def multi_compute(f): return compute2(f, 2, candidate=5, verbose=False)
    # candidate = 5
    # for weight in range(2, 20, 2):
    #     forms = Mk_mod_n(weight, candidate)
    #     print(f"Got {len(forms)} weight {weight} forms")

    #     with Pool(processes=len(sched_getaffinity(0))+1) as pool:
    #         for n, response in enumerate(pool.imap_unordered(multi_compute, forms)):
    #             for line in response:
    #                 print(f"{n+1:>4}/{len(forms)} = {(n+1)/len(forms)*100:z5.1f}%, ", line)

    # def multi_compute(candidate): return compute2(S('Q^3'), 2, candidate=candidate, verbose=False)
    # with Pool(processes=len(sched_getaffinity(0))+1) as pool:
    #     for n, response in enumerate(pool.imap_unordered(multi_compute, P)):
    #         for line in response: print(line)

    def multi_compute(candidate): return compute(S('Q^3'), 2, candidate=candidate, verbose=False)
    with Pool(processes=len(sched_getaffinity(0))+1) as pool:
        for n, response in enumerate(pool.imap_unordered(multi_compute, P)):
            for line in response: print(line)

    # if len(argv) > 2:
    #     f = S(argv[1])
    #     order = int(argv[2])
    #     compute2(f, order, OS=False, verbose=False)
    #     # Recursion(f, order, OS=True)
    # else:
    #     print("Call with function (e.g. 'Q^3 - R^2') and order (2 or 3)")
    #     print("Full example: python3 script.py 'Q^3 - R^2' 2")
    #     exit(1)
